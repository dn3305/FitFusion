import requests
import certifi
from bs4 import BeautifulSoup
import csv
import ssl

# ---------------------------
# Configuration: headers and cookies
# ---------------------------
cookies = {
    'JSESSIONID': '	02E62E6483634774FB712EBE28E64DEC',  # Update if needed
}

headers = {
    'Accept': 'application/xml, text/xml, */*; q=0.01',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Origin': 'https://rera.karnataka.gov.in',
    'Pragma': 'no-cache',
    'Referer': 'https://rera.karnataka.gov.in/projectViewDetails',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                   'AppleWebKit/537.36 (KHTML, like Gecko) '
                   'Chrome/131.0.0.0 Safari/537.36'),
    'X-Requested-With': 'XMLHttpRequest',
}

cert_path = './rera.pem'
ssl_context = ssl.create_default_context(cafile=cert_path)
response = requests.get("https://rera.karnataka.gov.in/projectDetails", verify=cert_path)

# ---------------------------
# URL for fetching project details
# ---------------------------
project_details_url = "https://rera.karnataka.gov.in/projectDetails"

# ---------------------------
# Set payload with action:6
# ---------------------------
payload_details = {'action': '12822'}

# ---------------------------
# Step 1: Send POST request with payload action:6
# ---------------------------
try:
    response_details = requests.post(
        project_details_url,
        headers=headers,
        cookies=cookies,
        data=payload_details,
        verify=cert_path  # Replace with your cert file if needed
    )
    response_details.raise_for_status()
    print("Project details fetched successfully.")
except requests.exceptions.RequestException as e:
    print(f"Error fetching project details: {e}")
    exit()

# ---------------------------
# Step 2: Debug - Print and save the raw response
# ---------------------------
raw_text = response_details.text
print("---- Raw Response Start ----")
print(raw_text)
print("---- Raw Response End ----")

# Optionally, write the raw response to a file for inspection.
with open("raw_response.html", "w", encoding="utf-8") as f:
    f.write(raw_text)

# ---------------------------
# Step 3: Parse the response using BeautifulSoup
# ---------------------------
content_type = response_details.headers.get('Content-Type', '').lower()
if 'xml' in content_type:
    soup = BeautifulSoup(raw_text, "xml")
else:
    soup = BeautifulSoup(raw_text, "html.parser")

# ---------------------------
# Step 4: Extract project details using row approach
# ---------------------------
# This method loops through all <div class="row"> elements and, if a row has at least 2 columns (with class "col-md-3"),
# it treats the first as a label and the second as the value.
data = {}

rows = soup.find_all("div", class_="row")
for row in rows:
    cols = row.find_all("div", class_="col-md-3")
    if len(cols) >= 2:
        # Get the label text and remove the trailing colon (if any)
        label = cols[0].get_text(strip=True).replace(":", "")
        # Get the value text. This will capture text within a <p> or an <a> tag.
        value = cols[1].get_text(strip=True)
        # Save in dictionary. If a label appears multiple times, the last value overwrites previous ones.
        data[label] = value

# For debugging, print all extracted label/value pairs:
print("Extracted project details (label: value):")
for label, value in data.items():
    print(f"{label}: {value}")

# ---------------------------
# (Optional) Step 5: Save details to CSV
# ---------------------------
# You can either save all the extracted pairs or choose specific ones.
csv_filename = "rera_project_details.csv"
try:
    with open(csv_filename, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        # Write header row: using the keys from the dictionary.
        writer.writerow(["Field", "Value"])
        for label, value in data.items():
            writer.writerow([label, value])
    print(f"Project details saved to {csv_filename}")
except Exception as e:
    print(f"Error saving CSV file: {e}")
